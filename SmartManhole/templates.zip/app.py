from flask import Flask, render_template, jsonify, send_file, request, flash, session, redirect, url_for,session
from flask_session import Session
import firebase_admin
from firebase_admin import credentials, firestore, initialize_app, storage, db
import os
from datetime import datetime, timedelta
from config import Config
from pyrebase import pyrebase
from flask_mail import Mail, Message
from firebase_admin import storage as firebase_storage
from datetime import datetime, timedelta, timezone
from google.cloud.firestore_v1 import GeoPoint
from opencage.geocoder import OpenCageGeocode
from flask_wtf import FlaskForm
from wtforms import SubmitField
from wtforms.validators import DataRequired
import json

app = Flask(__name__)
# Define the MaintenanceForm
class MaintenanceForm(FlaskForm):
    pass


# Configure Flask Mail
app.config['MAIL_SERVER'] = 'your_smtp_server'
app.config['MAIL_PORT'] = 587  # Use the appropriate port for your SMTP server
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False

# Set the default sender as a placeholder; it will be dynamically updated later
app.config['MAIL_DEFAULT_SENDER'] = 'noreply@example.com'

mail = Mail(app)

# Initialize Firebase using the service account key
cred = credentials.Certificate(
    r'C:\Users\User\OneDrive\Documents\IDP\Idp\smart-manhole-f5530-firebase-adminsdk-rl149-71b37516ed.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://smart-manhole-f5530-default-rtdb.firebaseio.com/'
})

# Reference to the database root
db_ref = db.reference('/UsersData/RAs75wzNpMWkiVV4MmswnaD8Ul03/readings')

app.config.from_object(Config)
app.secret_key = 'your_secret_key'

OPENCAGE_API_KEY = '634f043ea4704503bf62305a2d30b3ac'


# Firebase configuration
firebaseConfig = {
    'apiKey': "AIzaSyC4tzOcu-ADuJxhwyiw0cPYLLdjSqTvKz4",
    'authDomain': "smart-manhole-f5530.firebaseapp.com",
    'databaseURL': "https://smart-manhole-f5530-default-rtdb.firebaseio.com",
    'projectId': "smart-manhole-f5530",
    'storageBucket': "smart-manhole-f5530.appspot.com",
    'messagingSenderId': "561649259899",
    'appId': "1:561649259899:web:cfce85efc06cdb9d4759de",
    'measurementId': "G-H3H55QGNCD"
}

firebase = pyrebase.initialize_app(firebaseConfig)
auth = firebase.auth()
db = firebase.database()

# Initialize Firebase using credentials.json
cred = credentials.Certificate(
    r'C:\Users\User\OneDrive\Documents\Year 3\SmartManhole\smart-manhole-f5530-firebase-adminsdk-rl149-f2d3b9b900.json')
firebase_admin.initialize_app(cred, {'databaseURL': 'https://smart-manhole-f5530-default-rtdb.firebaseio.com/'},
                              name='first_app')
firestore_db = firestore.client()


# Route for Authentication
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/home')
def home():
    return render_template('home.html')


@app.route('/login', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        try:
            user = auth.sign_in_with_email_and_password(email, password)
            session['user_email'] = email

            # Update the MAIL_DEFAULT_SENDER with the login user's email
            app.config['MAIL_DEFAULT_SENDER'] = email

            return redirect(url_for('report_dashboard'))

        except Exception as e:
            print(f'Error: {e}')
            flash('Invalid email or password. Please try again', 'error')

    return render_template('login.html')


@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.pop('user_email', None)
    flash('Logged out successfully', 'success')
    return redirect(url_for('home'))


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        try:
            auth.create_user_with_email_and_password(email, password)

            # Automatically log in the user after successful registration
            user = auth.sign_in_with_email_and_password(email, password)
            session['user_email'] = email

            flash('User created successfully! Please log in.', 'success')
            return redirect(url_for('monitoring'))
        except Exception as e:
            flash(f'Error: {e}')

    return render_template('signup.html')


@app.route('/report_dashboard', methods=['GET', 'POST'])
def report_dashboard():
    user_email = session.get('user_email')

    if not user_email:
        flash('You are not logged in. Please log in to access the dashboard.', 'error')
        return redirect(url_for('login'))

    # Fetch data from Firestore Manhole collection
    manhole_data = []

    # Get the search query from the request
    search_query = request.args.get('search', '').strip()

    # Retrieve data based on search query
    if search_query:
        # Perform a Firestore query to filter based on the search query
        # Modify this query based on your specific requirements
        collection_ref = firestore_db.collection('Manhole report')
        manhole_docs = collection_ref.where('Remarks', '>=', search_query).where('Remarks', '<=', search_query + '\uf8ff').stream()
    else:
        # Retrieve all data if no search query is provided
        collection_ref = firestore_db.collection('Manhole report')
        manhole_docs = collection_ref.stream()

    for doc in manhole_docs:
        # Extract specific fields from each document
        cover_status = doc.get('Cover_Status')
        remarks = doc.get('Remarks')
        timestamp = doc.get('timestamp')
        report_id = doc.id

        # Extract GeoPoint information
        location = doc.get('Location')  # Assuming 'location' is the field name
        # Extract latitude and longitude from GeoPoint
        latitude = location.latitude if location else None
        longitude = location.longitude if location else None

        # Get the city name using the OpenCage Geocoding API
        city_name = get_city_name(latitude, longitude)

        # Image
        image_url = get_image_url(report_id)

        # Add extracted data to the list
        manhole_data.append({
            'id': report_id,
            'Cover_Status': str(cover_status) if cover_status else '',
            'Remarks': remarks,
            'Timestamp': timestamp,
            'Latitude': latitude,
            'Longitude': longitude,
            'Location': city_name,  # Replace with the city name
            'Image_url': image_url
        })

    return render_template('firebase.html', data=manhole_data, search_query=search_query)

def get_city_name(latitude, longitude):
    ocg = OpenCageGeocode('634f043ea4704503bf62305a2d30b3ac')
    # Make a request to the OpenCage Geocoding API
    results = ocg.reverse_geocode(latitude, longitude)

    # Extract the city from the API response
    if results and results[0] and 'formatted' in results[0]:
        city = results[0]['formatted']
        return city
    else:
        return 'N/A'

# Function to retrieve image URL from Firebase Storage
def get_image_url(report_id):
    try:
        # Get a reference to the bucket
        bucket = firebase_storage.bucket('smart-manhole-f5530.appspot.com')

        # Specify the path to the image in the bucket
        blob = bucket.blob(f'images/{report_id}.jpg')

        # Check if the blob (file) exists
        if not blob.exists():
            # print(f"Image does not exist for report_id {report_id}")
            return ''

        # Get the current time in UTC
        current_time_utc = datetime.now(timezone.utc)

        # Generate the signed URL with an expiration time of 1 hour
        expiration_time = current_time_utc + timedelta(hours=1)

        # Get the signed URL only if the blob exists
        image_url = blob.generate_signed_url(expiration=expiration_time, method='GET')

        return image_url

    except Exception as e:
        print(f"Error getting image URL for report_id {report_id}: {e}")
        return ''


# Define the route to handle the form
# Define the route to handle the form
@app.route('/maintenance/<manhole_id>', methods=['GET', 'POST'])
def maintenance_page(manhole_id):
    if request.method == 'POST':
        manhole_data = {key.replace("manhole_data_", ""): value for key, value in request.form.items() if
                        "manhole_data_" in key}
        print("pass")
        print(manhole_data)


        form = MaintenanceForm()

        selected_date = None


    if form.validate_on_submit():
        selected_date = request.form['selected_date']
        print("here")
        # Check if the "Send" or "Send Selected Documents" button is clicked
        if 'send_email' in request.form:
            print("here2")
            # selected_documents = request.form.getlist('selected_documents')
            deadline = request.form['deadline']  # Get the deadline value

            # Check if at least one document is selected
            # if not selected_documents:
            #     print("here3")
            #     return render_template('maintenance_page.html', manhole_data=manhole_data, form=form,  selected_date=selected_date, selected_documents=selected_documents,  error_message='Please choose at least one document for sending.')

            # Proceed with sending email for selected documents and deadline
            send_selected_documents_email(manhole_data,selected_date, deadline)

    return render_template('maintenance_page.html', manhole_id=manhole_id, manhole_data=manhole_data, form=form, selected_date=selected_date )


    return manhole_details
# Define the function to send email for selected documents and deadline
def send_selected_documents_email(manhole_data, selected_date,  deadline):
    try:
        if selected_date and manhole_data.get(selected_date) :
            recipient_email = 'lxr2002@gmail.com'  # Replace with the recipient's email address
            print("yes")
            # Filter selected documents from manhole_data
            # selected_data = {selected_date: []}
            # for manhole in manhole_data[selected_date]:
            #     if manhole['id'] in selected_documents:
            #         selected_data[selected_date].append(manhole)

            # Convert selected_data to JSON before passing it to the email template
            # selected_data_json = json.dumps(selected_data)

            selected_data_json = json.dumps(manhole_data)
            # Send the email with selected data and deadline
            subject = f'Selected Maintenance Data for {selected_date}'
            body_html = render_template('email_template.html',  deadline=deadline, manhole_data=selected_data_json)

            msg = Message(subject,
                          recipients=[recipient_email],
                          body=body_html,
                          sender=('Your Organization', 'noreply@example.com'),
                          reply_to='noreply@example.com',
                          extra_headers={'Precedence': 'bulk'},
                          html=body_html)
            mail.send(msg)

            return 'Email sent successfully!'
        else:
            return 'No data available to send.'
    except Exception as e:
        print("no")
        return f'Error: {str(e)}'

@app.route('/sensor')
def sensor():
    # Retrieve data from the Realtime Database
    sensor_data = db_ref.get()

    # Convert data to a list for rendering
    sensor_list = []
    for key, value in sensor_data.items():
        timestamp = value.get('timestamp', '')
        temperature = value.get('temperature', '')
        carbon_monoxide = value.get('carbon_monoxide', '')
        methane = value.get('Methane', '')  # New field
        tilting_angle_x = value.get('Tilting_angle_x', '')  # New field
        tilting_angle_y = value.get('Tilting_angle_y', '')  # New field
        tilting_angle_z = value.get('Tilting_angle_z', '')  # New field
        water_level = value.get('Water_level', '')  # New field

        sensor_list.append({
            'timestamp': timestamp,
            'temperature': temperature,
            'carbon_monoxide': carbon_monoxide,
            'methane': methane,
            'tilting_angle_x': tilting_angle_x,
            'tilting_angle_y': tilting_angle_y,
            'tilting_angle_z': tilting_angle_z,
            'water_level': water_level
        })



if __name__ == '__main__':
    app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'
    app.run(debug=True)